// Vanilla javascript utilizing Fetch API and x-www-form-urlencoded
let allProducts = [];
let cart = [];
const GST_RATE = 0.18;

// Security check (very basic client-side for demo)
function checkAuth() {
    if(!sessionStorage.getItem("loggedIn")) {
        window.location.href = "index.html";
    }
}

function logout() {
    sessionStorage.removeItem("loggedIn");
    window.location.href = "index.html";
}

// Show alert message
function showAlert(msg) {
    const el = document.getElementById("alertBox") || document.getElementById("errorBox");
    if(el) {
        el.innerText = msg;
        el.style.display = "block";
        setTimeout(() => { el.style.display="none"; }, 3000);
    }
}

// Helper to URL encode object
function urlEncode(obj) {
    return Object.keys(obj).map(k => encodeURIComponent(k) + '=' + encodeURIComponent(obj[k])).join('&');
}

/* ================================= LOGIN API ================================= */
function login(user, pass) {
    fetch('/SmartBillingSystem/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: urlEncode({ username: user, password: pass })
    })
    .then(res => res.json())
    .then(data => {
        if(data.status === 'success') {
            sessionStorage.setItem("loggedIn", "true");
            window.location.href = "dashboard.html";
        } else {
            showAlert("Invalid Credentials!");
        }
    }).catch(err => {
        showAlert("Server connection error");
    });
}


/* =============================== PRODUCTS API ================================ */
function loadProducts() {
    fetch('/SmartBillingSystem/api/products')
    .then(res => res.json())
    .then(data => {
        allProducts = data;
        const tbody = document.getElementById('productTableBody');
        if(!tbody) return;
        tbody.innerHTML = "";
        data.forEach(p => {
            let row = `<tr>
                <td>${p.id}</td>
                <td>${p.name}</td>
                <td>₹${p.price.toFixed(2)}</td>
                <td style="color:${p.stock < 10 ? 'red' : 'black'}">${p.stock}</td>
                <td><button class='danger' onclick='deleteProduct(${p.id})'>Delete</button></td>
            </tr>`;
            tbody.innerHTML += row;
        });
    });
}

function addProduct(name, price, stock) {
    fetch('/SmartBillingSystem/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: urlEncode({ name, price, stock })
    }).then(res => res.json()).then(data => {
        if(data.status === 'success') {
            loadProducts();
            showAlert("Product Added");
        } else showAlert("Error adding product");
    });
}

function deleteProduct(id) {
    if(!confirm("Are you sure?")) return;
    
    // Some old Tomcats strict block DELETE bodies. Another option is url parameters.
    fetch(`/SmartBillingSystem/api/products?id=${id}`, {
        method: 'DELETE'
    }).then(res => res.json()).then(data => {
        loadProducts();
    });
}

function loadDashboardStats() {
    // Quick load just to count
    fetch('/SmartBillingSystem/api/products').then(r=>r.json()).then(d=> {
        document.getElementById("statProducts").innerText = d.length;
    });
    fetch('/SmartBillingSystem/api/orders').then(r=>r.json()).then(d=> {
        document.getElementById("statOrders").innerText = d.length;
    });
}


/* =============================== BILLING SYSTEM ============================== */

// Populating dropdown map
let productMap = {};

function loadProductsForDropdown() {
    fetch('/SmartBillingSystem/api/products')
    .then(res => res.json())
    .then(data => {
        const select = document.getElementById('billProduct');
        if(!select) return;
        
        select.innerHTML = "";
        data.forEach(p => {
            productMap[p.id] = p; // Store fast ref
            
            let opt = document.createElement('option');
            opt.value = p.id;
            opt.text = `${p.name} - ₹${p.price} (${p.stock} left)`;
            if(p.stock <= 0) opt.disabled = true;
            select.appendChild(opt);
        });
    });
}

function addToBill() {
    const pid = document.getElementById('billProduct').value;
    let qty = parseInt(document.getElementById('billQty').value);
    
    if(!pid || qty <= 0) return;
    
    const p = productMap[pid];
    if(qty > p.stock) {
        showAlert("Not enough stock available!");
        return;
    }

    // Check if already in cart
    const existingIndex = cart.findIndex(c => c.id == pid);
    if(existingIndex > -1) {
        if (cart[existingIndex].qty + qty > p.stock) {
            showAlert("Exceeds stock limit!");
            return;
        }
        cart[existingIndex].qty += qty;
    } else {
        cart.push({ id: p.id, name: p.name, price: p.price, qty: qty });
    }
    
    renderCart();
}

function removeFromBill(index) {
    cart.splice(index, 1);
    renderCart();
}

function renderCart() {
    const tbody = document.getElementById('cartTableBody');
    tbody.innerHTML = "";
    
    let subtotal = 0;
    
    cart.forEach((item, idx) => {
        let total = item.price * item.qty;
        subtotal += total;
        
        tbody.innerHTML += `<tr>
            <td>${item.name}</td>
            <td>₹${item.price.toFixed(2)}</td>
            <td>${item.qty}</td>
            <td>₹${total.toFixed(2)}</td>
            <td><button style='padding:4px 8px; font-size:12px;' class='danger' onclick='removeFromBill(${idx})'>X</button></td>
        </tr>`;
    });
    
    let gst = subtotal * GST_RATE;
    let net = subtotal + gst;
    
    document.getElementById('subtotalLabel').innerText = `₹${subtotal.toFixed(2)}`;
    document.getElementById('gstLabel').innerText = `₹${gst.toFixed(2)}`;
    document.getElementById('netTotalLabel').innerText = `₹${net.toFixed(2)}`;
}

function completeCheckout() {
    if(cart.length === 0) {
       showAlert("Cart is empty!");
       return;
    }

    let subtotal = cart.reduce((sum, item) => sum + (item.price * item.qty), 0);
    let gst = subtotal * GST_RATE;
    let total = subtotal + gst;
    
    // Create delimited string id:qty,id:qty
    let itemsStr = cart.map(c => `${c.id}:${c.qty}`).join(',');

    fetch('/SmartBillingSystem/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: urlEncode({ items: itemsStr, subtotal: subtotal, gst: gst, total: total })
    }).then(r => r.json()).then(data => {
        if(data.status === 'success') {
            alert(`Order Placed Succesfully! ID: ${data.orderId}`);
            cart = [];
            renderCart();
            loadProductsForDropdown(); // update stock dropdown
        } else {
            showAlert("Failed to save order");
        }
    });
}


/* =============================== ORDERS TABLE ============================== */
function loadOrders() {
    fetch('/SmartBillingSystem/api/orders')
    .then(res => res.json())
    .then(data => {
        const tbody = document.getElementById('ordersTableBody');
        if(!tbody) return;
        tbody.innerHTML = "";
        data.forEach(o => {
            let row = `<tr>
                <td>ORD-${o.id}</td>
                <td>${o.date}</td>
                <td>₹${o.subtotal.toFixed(2)}</td>
                <td>₹${o.gst.toFixed(2)}</td>
                <td style="font-weight:bold; color:var(--dark)">₹${o.total.toFixed(2)}</td>
            </tr>`;
            tbody.innerHTML += row;
        });
    });
}
