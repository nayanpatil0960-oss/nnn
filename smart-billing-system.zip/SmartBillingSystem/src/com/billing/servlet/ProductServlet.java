package com.billing.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.billing.util.DbUtil;

// Standard Java Servlets, using simple String concatenations for JSON.
@WebServlet("/api/products")
public class ProductServlet extends HttpServlet {
    
    // Get all products
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try (Connection conn = DbUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM products");
            ResultSet rs = ps.executeQuery();

            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            while(rs.next()) {
                if(!first) { json.append(","); }
                json.append("{")
                    .append("\"id\":").append(rs.getInt("id")).append(",")
                    .append("\"name\":\"").append(rs.getString("name")).append("\",")
                    .append("\"price\":").append(rs.getDouble("price")).append(",")
                    .append("\"stock\":").append(rs.getInt("stock"))
                    .append("}");
                first = false;
            }
            json.append("]");
            out.print(json.toString());
        } catch (Exception e) {
            out.print("[]");
        }
    }

    // Add new product
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        double price = Double.parseDouble(request.getParameter("price"));
        int stock = Integer.parseInt(request.getParameter("stock"));

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try (Connection conn = DbUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("INSERT INTO products(name, price, stock) VALUES(?, ?, ?)");
            ps.setString(1, name);
            ps.setDouble(2, price);
            ps.setInt(3, stock);
            int k = ps.executeUpdate();
            
            if(k > 0) out.print("{\"status\":\"success\"}");
            else out.print("{\"status\":\"error\"}");
        } catch (Exception e) {
            e.printStackTrace();
            out.print("{\"status\":\"error\"}");
        }
    }

    // Delete product
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        PrintWriter out = response.getWriter();

        try (Connection conn = DbUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("DELETE FROM products WHERE id = ?");
            ps.setInt(1, id);
            ps.executeUpdate();
            out.print("{\"status\":\"success\"}");
        } catch (Exception e) {
            out.print("{\"status\":\"error\"}");
        }
    }
}
