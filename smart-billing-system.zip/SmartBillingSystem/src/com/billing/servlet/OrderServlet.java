package com.billing.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.billing.util.DbUtil;

@WebServlet("/api/orders")
public class OrderServlet extends HttpServlet {
    
    // Receives a custom delimited string for simplicity: product_id:qty,product_id:qty... 
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        String itemsPayload = request.getParameter("items"); // format: id:qty,id:qty
        double subtotal = Double.parseDouble(request.getParameter("subtotal"));
        double gst = Double.parseDouble(request.getParameter("gst"));
        double total = Double.parseDouble(request.getParameter("total"));

        Connection conn = null;
        try {
            conn = DbUtil.getConnection();
            conn.setAutoCommit(false); // Map everything into a single transaction
            
            // 1. Insert Order
            String orderSql = "INSERT INTO orders (subtotal, gst_amount, net_total) VALUES (?, ?, ?)";
            PreparedStatement psOrder = conn.prepareStatement(orderSql, Statement.RETURN_GENERATED_KEYS);
            psOrder.setDouble(1, subtotal);
            psOrder.setDouble(2, gst);
            psOrder.setDouble(3, total);
            psOrder.executeUpdate();
            
            ResultSet rsKeys = psOrder.getGeneratedKeys();
            int orderId = 0;
            if(rsKeys.next()) {
                orderId = rsKeys.getInt(1);
            }

            // 2. Insert Items & Reduce Stock
            String[] items = itemsPayload.split(",");
            String itemSql = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
            String stockSql = "UPDATE products SET stock = stock - ? WHERE id = ?";
            
            PreparedStatement psItem = conn.prepareStatement(itemSql);
            PreparedStatement psStock = conn.prepareStatement(stockSql);
            
            for(String item : items) {
                if(item.trim().isEmpty()) continue;
                String[] parts = item.split(":");
                int pid = Integer.parseInt(parts[0]);
                int qty = Integer.parseInt(parts[1]);
                
                // Fetch product price dynamically to be safe
                PreparedStatement psPrice = conn.prepareStatement("SELECT price FROM products WHERE id=?");
                psPrice.setInt(1, pid);
                ResultSet rsP = psPrice.executeQuery();
                double itemPrice = 0;
                if(rsP.next()) { itemPrice = rsP.getDouble("price"); }

                // Insert into order items
                psItem.setInt(1, orderId);
                psItem.setInt(2, pid);
                psItem.setInt(3, qty);
                psItem.setDouble(4, itemPrice);
                psItem.executeUpdate();
                
                // Reduce stock
                psStock.setInt(1, qty);
                psStock.setInt(2, pid);
                psStock.executeUpdate();
            }

            conn.commit();
            out.print("{\"status\":\"success\", \"orderId\":" + orderId + "}");

        } catch (Exception e) {
            e.printStackTrace();
            if (conn != null) {
                try { conn.rollback(); } catch (Exception ex) {}
            }
            out.print("{\"status\":\"error\"}");
        } finally {
            if (conn != null) {
                try { conn.setAutoCommit(true); conn.close(); } catch (Exception ex) {}
            }
        }
    }

    // Get all past orders
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        
        try (Connection conn = DbUtil.getConnection()) {
            PreparedStatement ps = conn.prepareStatement("SELECT * FROM orders ORDER BY id DESC");
            ResultSet rs = ps.executeQuery();

            StringBuilder json = new StringBuilder("[");
            boolean first = true;
            while(rs.next()) {
                if(!first) { json.append(","); }
                json.append("{")
                    .append("\"id\":").append(rs.getInt("id")).append(",")
                    .append("\"subtotal\":").append(rs.getDouble("subtotal")).append(",")
                    .append("\"gst\":").append(rs.getDouble("gst_amount")).append(",")
                    .append("\"total\":").append(rs.getDouble("net_total")).append(",")
                    .append("\"date\":\"").append(rs.getString("order_date")).append("\"")
                    .append("}");
                first = false;
            }
            json.append("]");
            out.print(json.toString());
        } catch (Exception e) {
            out.print("[]");
        }
    }
}
