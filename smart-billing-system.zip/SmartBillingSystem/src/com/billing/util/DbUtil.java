package com.billing.util;

import java.sql.Connection;
import java.sql.DriverManager;

public class DbUtil {
    // Database credentials for XAMPP
    private static final String URL = "jdbc:mysql://localhost:3306/billing_db";
    private static final String USER = "root";
    private static final String PASS = ""; 

    public static Connection getConnection() {
        Connection conn = null;
        try {
            // Load MySQL Driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(URL, USER, PASS);
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Database Connection Error!");
        }
        return conn;
    }
}
