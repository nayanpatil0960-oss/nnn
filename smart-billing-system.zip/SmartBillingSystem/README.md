# Smart Billing System - Java Servlets + MySQL

This is a complete, beginner-friendly billing system using Java Servlets, Vanilla JS, HTML, CSS, and MySQL.

## Requirements
- XAMPP (for MySQL database)
- Apache Tomcat (9.x or 10.x recommended)
- Java JDK 8+
- Any Java IDE (Eclipse, IntelliJ) or you can compile manually.

## Setup Instructions

1. **Database Setup:**
   - Open XAMPP and start the **MySQL** module.
   - Go to phpMyAdmin (http://localhost/phpmyadmin).
   - Click "Import" and upload the `database.sql` file included in this bundle. This creates the `billing_db` and sample data.

2. **Project Setup (Eclipse / IntelliJ):**
   - Create a new "Dynamic Web Project" in Eclipse or a Java EE Web App in IntelliJ.
   - Name it `SmartBillingSystem`.
   - Copy the `WebContent` folder contents to your web directory (`webapp` or `WebContent`).
   - Copy the `src` folder contents to your Java source directory.

3. **Database Driver:**
   - Download the Native MySQL JDBC Driver (e.g., `mysql-connector-j-8.x.x.jar`).
   - Place the `.jar` file directly into your `WebContent/WEB-INF/lib` folder.

4. **Run Project:**
   - Add the project to your Apache Tomcat server inside your IDE.
   - Launch the server.
   - Open your browser and go to: `http://localhost:8080/SmartBillingSystem/index.html`

## Default Admin Credentials
- **Username:** admin
- **Password:** admin123
