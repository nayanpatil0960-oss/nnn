import { BookDown, Code, Database, FolderArchive } from 'lucide-react';
import React from 'react';

export default function App() {
  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 p-8 flex flex-col items-center">
      <div className="max-w-3xl w-full">
        <header className="mb-10 text-center">
          <div className="inline-block p-4 rounded-full bg-blue-100 text-blue-600 mb-4">
            <FolderArchive size={48} />
          </div>
          <h1 className="text-4xl font-bold tracking-tight mb-4">Your Java Project is Ready!</h1>
          <p className="text-lg text-slate-600">
            You requested a Java Servlets + MySQL backend with a Vanilla JS frontend.
            Because this live preview runs a Node.js web server, we have packaged your full code
            into a folder for you to download and run on XAMPP/Tomcat.
          </p>
        </header>

        <div className="grid md:grid-cols-2 gap-6 mb-8">
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
              <div className="flex items-center gap-3 mb-4">
                <Database className="text-blue-500" />
                <h3 className="font-semibold text-lg">1. MySQL Database</h3>
              </div>
              <p className="text-slate-600 text-sm">
                The full SQL dump is located at <code className="bg-slate-100 px-1 py-0.5 rounded text-xs text-slate-800">SmartBillingSystem/database.sql</code>. Import this file into phpMyAdmin via XAMPP.
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200">
              <div className="flex items-center gap-3 mb-4">
                <Code className="text-orange-500" />
                <h3 className="font-semibold text-lg">2. Java Web App</h3>
              </div>
              <p className="text-slate-600 text-sm">
                Clean and simple Java Servlets are inside the <code className="bg-slate-100 px-1 py-0.5 rounded text-xs text-slate-800">src/com/billing</code> folder, entirely following your constraints (no Spring Boot).
              </p>
            </div>
            
            <div className="bg-white p-6 rounded-xl shadow-sm border border-slate-200 col-span-1 md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <BookDown className="text-emerald-500" />
                <h3 className="font-semibold text-lg">How to Download Your Code</h3>
              </div>
              <div className="space-y-3">
                <div className="flex bg-slate-50 p-4 rounded-lg border border-slate-100 items-start gap-4">
                   <div className="bg-slate-800 font-bold text-white w-8 h-8 rounded-full flex items-center justify-center shrink-0">1</div>
                   <div>
                     <p className="font-medium">Open Settings Menu</p>
                     <p className="text-sm text-slate-500">In the Google AI Studio top-right toolbar, click the settings (gear) or meatball menu icon.</p>
                   </div>
                </div>
                <div className="flex bg-slate-50 p-4 rounded-lg border border-slate-100 items-start gap-4">
                   <div className="bg-slate-800 font-bold text-white w-8 h-8 rounded-full flex items-center justify-center shrink-0">2</div>
                   <div>
                     <p className="font-medium">Export to ZIP</p>
                     <p className="text-sm text-slate-500">Select "Export to ZIP" OR "Export to GitHub" and download all the generated files.</p>
                   </div>
                </div>
                <div className="flex bg-slate-50 p-4 rounded-lg border border-slate-100 items-start gap-4">
                   <div className="bg-slate-800 font-bold text-white w-8 h-8 rounded-full flex items-center justify-center shrink-0">3</div>
                   <div>
                     <p className="font-medium">Run locally in Tomcat</p>
                     <p className="text-sm text-slate-500">Open <code className="text-xs">SmartBillingSystem/README.md</code> for the step-by-step setup instructions to launch it on XAMPP and Tomcat.</p>
                   </div>
                </div>
              </div>
            </div>
        </div>

      </div>
    </div>
  );
}
